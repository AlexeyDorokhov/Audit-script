Find-Module Posh-SSH | Install-Module

Set-ExecutionPolicy Bypass