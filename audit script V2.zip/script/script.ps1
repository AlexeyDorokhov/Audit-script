clear
Import-Module Posh-SSH

$rez=import-csv "C:\\Users\USERNAME\Desktop\script\list.txt" -Delimiter "`t"
#Пример: d:\\list.txt
foreach($dt in $rez)
{
$login = $dt.login
$pass =$dt.pass
$file= "C:\\Users\USERNAME\Desktop\script\pass\\" +$dt.id
#Пример: d:\\Folder\\
$fileConf= $dt.id+".conf"
Write-Host "Connection to" $dt.ip "`t" $dt.name -ForegroundColor Green

try{
$password = Get-Content $file | ConvertTo-SecureString
$cred = New-Object System.Management.Automation.PSCredential($login,$password)

$SSHSession = New-SSHSession -ComputerName $dt.ip -Credential $cred -Verbose -AcceptKey:$true

if ($($SSHSession.Connected) -eq $true) 
{
Write-Host "OK" -ForegroundColor Green
$SSH = $SSHSession | New-SSHShellStream
Start-Sleep -Seconds 5
#необходимо указать нужную команду для вашего оборудования
#либо послать ряд команд, тогда просто продублируйте две нижние команды 

$SSH.WriteLine("set cli screen-width 0")
Start-Sleep -Seconds 2
$SSH.WriteLine("request support information")
Start-Sleep -Seconds 2
$SSH.WriteLine("show chassis environment")
Start-Sleep -Seconds 2
$SSH.WriteLine("show chassis led")
Start-Sleep -Seconds 2
$SSH.WriteLine("show route")
Start-Sleep -Seconds 2
$SSH.WriteLine("show route forwarding-table")
Start-Sleep -Seconds 2
$SSH.read() | Out-File -FilePath ("C:\\Users\USERNAME\Desktop\script\out\" +$fileConf)
Start-Sleep -Seconds 5
$ss=$SSHSession | Remove-SSHSession
}else
{
Write-Host "Error connection" -ForegroundColor Red
}

}catch
{
Write-Host "No access" -ForegroundColor Red
}

}