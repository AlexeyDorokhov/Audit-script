$rez=import-csv "C:\\Users\USERNAME\Desktop\script\list.txt" -Delimiter "`t"
#Пример: d:\\list.txt

foreach($dt in $rez)
{
$pass =$dt.pass
$file= "C:\\Users\dorok\USERNAME\script\pass\\" +$dt.id
#Пример: d:\\pass\\
$sec=ConvertTo-SecureString -String $pass -AsPlainText -Force
ConvertFrom-SecureString -SecureString $sec | Set-Content $file
}