clear
Import-Module Posh-SSH

$rez=import-csv "C:\Users\$($env:USERNAME)\Desktop\script\list.txt" -Delimiter "`t"
#Пример: d:\\list.txt
foreach($dt in $rez)
{
$login = $dt.login
$pass =$dt.pass
$file= "C:\Users\$($env:USERNAME)\Desktop\script\pass\" +$dt.id
#Пример: d:\\Folder\\
$fileConf= $dt.id+".conf"
Write-Host "Connection to" $dt.ip "`t" $dt.name -ForegroundColor Green

try{
$password = Get-Content $file | ConvertTo-SecureString
$cred = New-Object System.Management.Automation.PSCredential($login,$password)

$SSHSession = New-SSHSession -ComputerName $dt.ip -Credential $cred -Verbose -AcceptKey:$true

if ($($SSHSession.Connected) -eq $true) 
{
Write-Host "OK" -ForegroundColor Green
$SSH = $SSHSession | New-SSHShellStream
Start-Sleep -Seconds 5
#необходимо указать нужную команду для вашего оборудования
#либо послать ряд команд, тогда просто продублируйте две нижние команды 

$SSH.WriteLine("rows 0")
Start-Sleep -Seconds 2
$SSH.WriteLine("system controller show")
Start-Sleep -Seconds 5
$SSH.WriteLine("system controller hardware-license show")
Start-Sleep -Seconds 5
$SSH.WriteLine("system controller fru show")
Start-Sleep -Seconds 5
$SSH.WriteLine("system controller flash-cache show")
Start-Sleep -Seconds 5
$SSH.WriteLine("system configuration backup show")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage port show -instance -errors")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage port show")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage path show -switch")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage path show -detail")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage path show -by-target")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage path show -array")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage path show")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage disk show -raid-info-for-aggregate")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage disk show")
Start-Sleep -Seconds 5
$SSH.WriteLine("storage disk error show")
Start-Sleep -Seconds 5
$SSH.WriteLine("statistics vserver show")
Start-Sleep -Seconds 5
$SSH.WriteLine("statistics volume show")
Start-Sleep -Seconds 5
$SSH.WriteLine("network interface show -failover")
Start-Sleep -Seconds 5
$SSH.WriteLine("network interface show")
Start-Sleep -Seconds 5
$SSH.read() | Out-File -FilePath ("C:\Users\$($env:USERNAME)\Desktop\script\out\" +$fileConf)
Start-Sleep -Seconds 5
$ss=$SSHSession | Remove-SSHSession
}else
{
Write-Host "Error connection" -ForegroundColor Red
}

}catch
{
Write-Host "No access" -ForegroundColor Red
}

}