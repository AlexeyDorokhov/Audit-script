clear
Import-Module Posh-SSH

$rez=import-csv "C:\Users\$($env:USERNAME)\Desktop\script\list.csv" -Delimiter "`t"
#Пример: d:\\list.txt
foreach($dt in $rez)
{
$login = $dt.login
$pass =$dt.pass
$file= "C:\Users\$($env:USERNAME)\Desktop\script\pass\" +$dt.id
#Пример: d:\\Folder\\
$fileConf= $dt.id+".conf"
Write-Host "Connection to" $dt.ip "`t" $dt.name -ForegroundColor Green

try{
$password = Get-Content $file | ConvertTo-SecureString
$cred = New-Object System.Management.Automation.PSCredential($login,$password)

$SSHSession = New-SSHSession -ComputerName $dt.ip -Credential $cred -Verbose -AcceptKey:$true

if ($($SSHSession.Connected) -eq $true) 
{
Write-Host "OK" -ForegroundColor Green
$SSH = $SSHSession | New-SSHShellStream
Start-Sleep -Seconds 5
#необходимо указать нужную команду для вашего оборудования
#либо послать ряд команд, тогда просто продублируйте две нижние команды 

$SSH.WriteLine("rows 0")
Start-Sleep -Seconds 2
$SSH.WriteLine("system controller fru show-manufacturing-info")
Start-Sleep -Seconds 2
$SSH.WriteLine("system feature-usage show-summary")
Start-Sleep -Seconds 2
$SSH.WriteLine("storage aggregate show")
Start-Sleep -Seconds 2
$SSH.WriteLine("storage aggregate show-status")
Start-Sleep -Seconds 2
$SSH.WriteLine("storage aggregate show-spare-disks")
Start-Sleep -Seconds 2
$SSH.WriteLine("vserver show")
Start-Sleep -Seconds 2
$SSH.WriteLine("vserver nfs show")
Start-Sleep -Seconds 2
$SSH.WriteLine("vserver cifs show")
Start-Sleep -Seconds 2
$SSH.WriteLine("vserver iscsi show")
Start-Sleep -Seconds 2
$SSH.WriteLine("vserver iscsi initiator show")
Start-Sleep -Seconds 2
$SSH.WriteLine("system health alert show")
Start-Sleep -Seconds 2
$SSH.WriteLine("storage errors show")
Start-Sleep -Seconds 2
$SSH.read() | Out-File -FilePath ("C:\Users\$($env:USERNAME)\Desktop\script\out\" +$fileConf)
Start-Sleep -Seconds 5
$ss=$SSHSession | Remove-SSHSession
}else
{
Write-Host "Error connection" -ForegroundColor Red
}

}catch
{
Write-Host "No access" -ForegroundColor Red
}

}