$rez=import-csv "C:\Users\$($env:USERNAME)\Desktop\script\list.csv" -Delimiter "`t"
#Пример: d:\\list.txt

foreach($dt in $rez)
{
$pass =$dt.pass
$file= "C:\Users\$($env:USERNAME)\Desktop\script\pass\" +$dt.id
#Пример: d:\\pass\\
$sec=ConvertTo-SecureString -String $pass -AsPlainText -Force
ConvertFrom-SecureString -SecureString $sec | Set-Content $file
}